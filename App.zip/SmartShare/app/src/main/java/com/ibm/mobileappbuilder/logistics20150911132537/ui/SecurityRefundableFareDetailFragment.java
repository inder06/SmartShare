
package com.ibm.mobileappbuilder.logistics20150911132537.ui;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.TextView;
import com.ibm.mobileappbuilder.logistics20150911132537.R;
import ibmmobileappbuilder.behaviors.ShareBehavior;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.SecurityDSItem;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.SecurityDS;

public class SecurityRefundableFareDetailFragment extends ibmmobileappbuilder.ui.DetailFragment<SecurityDSItem> implements ShareBehavior.ShareListener  {

    private Datasource<SecurityDSItem> datasource;
    public static SecurityRefundableFareDetailFragment newInstance(Bundle args){
        SecurityRefundableFareDetailFragment fr = new SecurityRefundableFareDetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public SecurityRefundableFareDetailFragment(){
        super();
    }

    @Override
    public Datasource<SecurityDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = SecurityDS.getInstance(new SearchOptions());
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        addBehavior(new ShareBehavior(getActivity(), this));

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.securityrefundablefaredetail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final SecurityDSItem item, View view) {
        
        TextView view0 = (TextView) view.findViewById(R.id.view0);
        view0.setText("Distance");
        
        
        TextView view1 = (TextView) view.findViewById(R.id.view1);
        view1.setText("Refundable Amount");
        
    }

    @Override
    protected void onShow(SecurityDSItem item) {
        // set the title for this fragment
        getActivity().setTitle("Security");
    }
    @Override
    public void onShare() {
        SecurityDSItem item = getItem();

        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");

        intent.putExtra(Intent.EXTRA_TEXT, "Distance" + "\n" +
                    "Refundable Amount");
        intent.putExtra(Intent.EXTRA_SUBJECT, "Security");
        startActivityForResult(Intent.createChooser(intent, getString(R.string.share)), 1);
    }
}

