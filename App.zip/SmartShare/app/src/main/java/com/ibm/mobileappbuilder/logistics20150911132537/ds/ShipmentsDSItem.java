
package com.ibm.mobileappbuilder.logistics20150911132537.ds;
import java.util.Date;
import java.util.Date;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class ShipmentsDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("vechicleId") public Long vechicleId;
    @SerializedName("pickup") public Date pickup;
    @SerializedName("scheduledDelivery") public Date scheduledDelivery;
    @SerializedName("fromAddress") public String fromAddress;
    @SerializedName("fromCity") public String fromCity;
    @SerializedName("fromZIP") public Long fromZIP;
    @SerializedName("fromCountry") public String fromCountry;
    @SerializedName("toAddress") public String toAddress;
    @SerializedName("toCity") public String toCity;
    @SerializedName("toZIP") public Long toZIP;
    @SerializedName("toCountry") public String toCountry;
    @SerializedName("status") public String status;
    @SerializedName("id") public String id;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(vechicleId);
        dest.writeValue(pickup != null ? pickup.getTime() : null);
        dest.writeValue(scheduledDelivery != null ? scheduledDelivery.getTime() : null);
        dest.writeString(fromAddress);
        dest.writeString(fromCity);
        dest.writeValue(fromZIP);
        dest.writeString(fromCountry);
        dest.writeString(toAddress);
        dest.writeString(toCity);
        dest.writeValue(toZIP);
        dest.writeString(toCountry);
        dest.writeString(status);
        dest.writeString(id);
    }

    public static final Creator<ShipmentsDSItem> CREATOR = new Creator<ShipmentsDSItem>() {
        @Override
        public ShipmentsDSItem createFromParcel(Parcel in) {
            ShipmentsDSItem item = new ShipmentsDSItem();

            item.vechicleId = (Long) in.readValue(null);
            Long pickupAux = (Long) in.readValue(null);
            item.pickup = pickupAux != null ? new Date(pickupAux) : null;
            Long scheduledDeliveryAux = (Long) in.readValue(null);
            item.scheduledDelivery = scheduledDeliveryAux != null ? new Date(scheduledDeliveryAux) : null;
            item.fromAddress = in.readString();
            item.fromCity = in.readString();
            item.fromZIP = (Long) in.readValue(null);
            item.fromCountry = in.readString();
            item.toAddress = in.readString();
            item.toCity = in.readString();
            item.toZIP = (Long) in.readValue(null);
            item.toCountry = in.readString();
            item.status = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public ShipmentsDSItem[] newArray(int size) {
            return new ShipmentsDSItem[size];
        }
    };

}


