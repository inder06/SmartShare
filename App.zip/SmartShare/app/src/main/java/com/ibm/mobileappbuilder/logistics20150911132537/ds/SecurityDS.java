

package com.ibm.mobileappbuilder.logistics20150911132537.ds;

import android.content.Context;

import java.net.URL;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.ds.restds.TypedByteArrayUtils;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * "SecurityDS" data source. (e37eb8dc-6eb2-4635-8592-5eb9696050e3)
 */
public class SecurityDS extends AppNowDatasource<SecurityDSItem>{

    // default page size
    private static final int PAGE_SIZE = 20;

    private SecurityDSService service;

    public static SecurityDS getInstance(SearchOptions searchOptions){
        return new SecurityDS(searchOptions);
    }

    private SecurityDS(SearchOptions searchOptions) {
        super(searchOptions);
        this.service = SecurityDSService.getInstance();
    }

    @Override
    public void getItem(String id, final Listener<SecurityDSItem> listener) {
        if ("0".equals(id)) {
                        getItems(new Listener<List<SecurityDSItem>>() {
                @Override
                public void onSuccess(List<SecurityDSItem> items) {
                    if(items != null && items.size() > 0) {
                        listener.onSuccess(items.get(0));
                    } else {
                        listener.onSuccess(new SecurityDSItem());
                    }
                }

                @Override
                public void onFailure(Exception e) {
                    listener.onFailure(e);
                }
            });
        } else {
                      service.getServiceProxy().getSecurityDSItemById(id, new Callback<SecurityDSItem>() {
                @Override
                public void success(SecurityDSItem result, Response response) {
                                        listener.onSuccess(result);
                }

                @Override
                public void failure(RetrofitError error) {
                                        listener.onFailure(error);
                }
            });
        }
    }

    @Override
    public void getItems(final Listener<List<SecurityDSItem>> listener) {
        getItems(0, listener);
    }

    @Override
    public void getItems(int pagenum, final Listener<List<SecurityDSItem>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
        int skipNum = pagenum * PAGE_SIZE;
        String skip = skipNum == 0 ? null : String.valueOf(skipNum);
        String limit = PAGE_SIZE == 0 ? null: String.valueOf(PAGE_SIZE);
        String sort = getSort(searchOptions);
                service.getServiceProxy().querySecurityDSItem(
                skip,
                limit,
                conditions,
                sort,
                null,
                null,
                new Callback<List<SecurityDSItem>>() {
            @Override
            public void success(List<SecurityDSItem> result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    private String[] getSearchableFields() {
        return new String[]{null};
    }

    // Pagination

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getUniqueValuesFor(String searchStr, final Listener<List<String>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
                service.getServiceProxy().distinct(searchStr, conditions, new Callback<List<String>>() {
             @Override
             public void success(List<String> result, Response response) {
                                  result.removeAll(Collections.<String>singleton(null));
                 listener.onSuccess(result);
             }

             @Override
             public void failure(RetrofitError error) {
                                  listener.onFailure(error);
             }
        });
    }

    @Override
    public URL getImageUrl(String path) {
        return service.getImageUrl(path);
    }

    @Override
    public void create(SecurityDSItem item, Listener<SecurityDSItem> listener) {
                          service.getServiceProxy().createSecurityDSItem(item, callbackFor(listener));
          }

    private Callback<SecurityDSItem> callbackFor(final Listener<SecurityDSItem> listener) {
      return new Callback<SecurityDSItem>() {
          @Override
          public void success(SecurityDSItem item, Response response) {
                            listener.onSuccess(item);
          }

          @Override
          public void failure(RetrofitError error) {
                            listener.onFailure(error);
          }
      };
    }

    @Override
    public void updateItem(SecurityDSItem item, Listener<SecurityDSItem> listener) {
                          service.getServiceProxy().updateSecurityDSItem(item.getIdentifiableId(), item, callbackFor(listener));
          }

    @Override
    public void deleteItem(SecurityDSItem item, final Listener<SecurityDSItem> listener) {
                service.getServiceProxy().deleteSecurityDSItemById(item.getIdentifiableId(), new Callback<SecurityDSItem>() {
            @Override
            public void success(SecurityDSItem result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    @Override
    public void deleteItems(List<SecurityDSItem> items, final Listener<SecurityDSItem> listener) {
                service.getServiceProxy().deleteByIds(collectIds(items), new Callback<List<SecurityDSItem>>() {
            @Override
            public void success(List<SecurityDSItem> item, Response response) {
                                listener.onSuccess(null);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    protected List<String> collectIds(List<SecurityDSItem> items){
        List<String> ids = new ArrayList<>();
        for(SecurityDSItem item: items){
            ids.add(item.getIdentifiableId());
        }
        return ids;
    }

}

