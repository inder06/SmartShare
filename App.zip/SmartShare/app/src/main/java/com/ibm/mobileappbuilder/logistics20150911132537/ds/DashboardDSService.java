
package com.ibm.mobileappbuilder.logistics20150911132537.ds;
import java.net.URL;
import com.ibm.mobileappbuilder.logistics20150911132537.R;
import ibmmobileappbuilder.ds.RestService;
import ibmmobileappbuilder.util.StringUtils;

/**
 * "DashboardDSService" REST Service implementation
 */
public class DashboardDSService extends RestService<DashboardDSServiceRest>{

    public static DashboardDSService getInstance(){
          return new DashboardDSService();
    }

    private DashboardDSService() {
        super(DashboardDSServiceRest.class);

    }

    @Override
    public String getServerUrl() {
        return "https://ibm-pods.buildup.io";
    }

    @Override
    protected String getApiKey() {
        return "QEFpsTzc";
    }

    @Override
    public URL getImageUrl(String path){
        return StringUtils.parseUrl("https://ibm-pods.buildup.io/app/57ef4eee57acb00300064c3f",
                path,
                "apikey=QEFpsTzc");
    }

}

