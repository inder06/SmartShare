

package com.ibm.mobileappbuilder.logistics20150911132537.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.Arrays;

import com.ibm.mobileappbuilder.logistics20150911132537.R;

import ibmmobileappbuilder.ui.BaseFragment;
import ibmmobileappbuilder.ui.FilterActivity;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;

import com.ibm.mobileappbuilder.logistics20150911132537.ds.ClientsDS;
import ibmmobileappbuilder.dialogs.ValuesSelectionDialog;
import ibmmobileappbuilder.views.ListSelectionPicker;
import java.util.ArrayList;

/**
 * SpotsFilterActivity filter activity
 */
public class SpotsFilterActivity extends FilterActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // set title
        setTitle(R.string.spotsFilterActivity);
    }

    @Override
    protected Fragment getFragment() {
        return new PlaceholderFragment();
    }

    public static class PlaceholderFragment extends BaseFragment {
        private SearchOptions.Builder searchOptionsBuilder = SearchOptions.Builder.searchOptions();
        private SearchOptions searchOptions;

        // filter field values
            
    ArrayList<String> city_values;
    
    ArrayList<String> country_values;

        public PlaceholderFragment() {
              searchOptions = SearchOptions.Builder.searchOptions().build();
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            return inflater.inflate(R.layout.spots_filter, container, false);
        }

        @Override
        public void onViewCreated(View view, Bundle savedInstanceState) {
            super.onViewCreated(view, savedInstanceState);

            // Get saved values
            Bundle bundle = savedInstanceState;
            if(bundle == null) {
                bundle = getArguments();
            }
            // get initial data
                        
            city_values = bundle.getStringArrayList("city_values");
            
            country_values = bundle.getStringArrayList("country_values");

            // bind pickers
                        
            final ListSelectionPicker city_view = (ListSelectionPicker) view.findViewById(R.id.city_filter);
            ValuesSelectionDialog city_dialog = (ValuesSelectionDialog) getFragmentManager().findFragmentByTag("city");
            if (city_dialog == null)
                city_dialog = new ValuesSelectionDialog();
            
            // configure the dialog
            city_dialog.setColumnName("city")
                .setDatasource(ClientsDS.getInstance(searchOptions))
                .setSearchOptions(searchOptions)
                .setTitle("City")
                .setHaveSearch(true)
                .setMultipleChoice(true);
            
            // bind the dialog to the picker
            city_view.setSelectionDialog(city_dialog)
                .setTag("city")
                .setSelectedValues(city_values)
                .setSelectedListener(new ListSelectionPicker.ListSelectedListener() {
                @Override
                public void onSelected(ArrayList<String> selected) {
                    city_values = selected;
                }
            });
            
            final ListSelectionPicker country_view = (ListSelectionPicker) view.findViewById(R.id.country_filter);
            ValuesSelectionDialog country_dialog = (ValuesSelectionDialog) getFragmentManager().findFragmentByTag("country");
            if (country_dialog == null)
                country_dialog = new ValuesSelectionDialog();
            
            // configure the dialog
            country_dialog.setColumnName("country")
                .setDatasource(ClientsDS.getInstance(searchOptions))
                .setSearchOptions(searchOptions)
                .setTitle("Country")
                .setHaveSearch(true)
                .setMultipleChoice(true);
            
            // bind the dialog to the picker
            country_view.setSelectionDialog(country_dialog)
                .setTag("country")
                .setSelectedValues(country_values)
                .setSelectedListener(new ListSelectionPicker.ListSelectedListener() {
                @Override
                public void onSelected(ArrayList<String> selected) {
                    country_values = selected;
                }
            });

            // Bind buttons
            Button okBtn = (Button) view.findViewById(R.id.ok);
            okBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();

                    // send filter result back to caller
                                        
                    intent.putStringArrayListExtra("city_values", city_values);
                    
                    intent.putStringArrayListExtra("country_values", country_values);

                    getActivity().setResult(RESULT_OK, intent);
                    getActivity().finish();
                }
            });

            Button cancelBtn = (Button) view.findViewById(R.id.reset);
            cancelBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Reset values
                                        
                    city_values = new ArrayList<String>();
                    city_view.setSelectedValues(null);
                    
                    country_values = new ArrayList<String>();
                    country_view.setSelectedValues(null);
                }
            });
        }

        @Override
        public void onSaveInstanceState(Bundle bundle) {
            super.onSaveInstanceState(bundle);

            // save current status
                        
            bundle.putStringArrayList("city_values", city_values);
            
            bundle.putStringArrayList("country_values", country_values);
        }
    }

}

