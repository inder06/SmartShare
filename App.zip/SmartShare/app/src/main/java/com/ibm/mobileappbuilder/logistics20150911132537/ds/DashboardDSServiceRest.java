
package com.ibm.mobileappbuilder.logistics20150911132537.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;

public interface DashboardDSServiceRest{

	@GET("/app/57ef4eee57acb00300064c3f/r/dashboardDS")
	void queryDashboardDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<DashboardDSItem>> cb);

	@GET("/app/57ef4eee57acb00300064c3f/r/dashboardDS/{id}")
	void getDashboardDSItemById(@Path("id") String id, Callback<DashboardDSItem> cb);

	@DELETE("/app/57ef4eee57acb00300064c3f/r/dashboardDS/{id}")
  void deleteDashboardDSItemById(@Path("id") String id, Callback<DashboardDSItem> cb);

  @POST("/app/57ef4eee57acb00300064c3f/r/dashboardDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<DashboardDSItem>> cb);

  @POST("/app/57ef4eee57acb00300064c3f/r/dashboardDS")
  void createDashboardDSItem(@Body DashboardDSItem item, Callback<DashboardDSItem> cb);

  @PUT("/app/57ef4eee57acb00300064c3f/r/dashboardDS/{id}")
  void updateDashboardDSItem(@Path("id") String id, @Body DashboardDSItem item, Callback<DashboardDSItem> cb);

  @GET("/app/57ef4eee57acb00300064c3f/r/dashboardDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
}

