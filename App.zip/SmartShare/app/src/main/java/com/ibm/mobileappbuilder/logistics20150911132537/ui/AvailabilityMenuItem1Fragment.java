package com.ibm.mobileappbuilder.logistics20150911132537.ui;

import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.TextView;
import com.ibm.mobileappbuilder.logistics20150911132537.R;
import ibmmobileappbuilder.behaviors.SearchBehavior;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ui.ListGridFragment;
import ibmmobileappbuilder.util.ViewHolder;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.ShipmentsDSItem;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.ShipmentsDS;
import android.content.Intent;
import ibmmobileappbuilder.util.Constants;

import static ibmmobileappbuilder.util.NavigationUtils.generateIntentToAddOrUpdateItem;

/**
 * "AvailabilityMenuItem1Fragment" listing
 */
public class AvailabilityMenuItem1Fragment extends ListGridFragment<ShipmentsDSItem>  {

    private Datasource<ShipmentsDSItem> datasource;


    public static AvailabilityMenuItem1Fragment newInstance(Bundle args) {
        AvailabilityMenuItem1Fragment fr = new AvailabilityMenuItem1Fragment();

        fr.setArguments(args);
        return fr;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addBehavior(new SearchBehavior(this));
    }

    protected SearchOptions getSearchOptions() {
      SearchOptions.Builder searchOptionsBuilder = SearchOptions.Builder.searchOptions();
      return searchOptionsBuilder.build();
    }


    /**
    * Layout for the list itselft
    */
    @Override
    protected int getLayout() {
        return R.layout.fragment_list;
    }

    /**
    * Layout for each element in the list
    */
    @Override
    protected int getItemLayout() {
        return R.layout.availabilitymenuitem1_item;
    }

    @Override
    protected Datasource<ShipmentsDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
      datasource = ShipmentsDS.getInstance(getSearchOptions());
      return datasource;
    }

    @Override
    protected void bindView(ShipmentsDSItem item, View view, int position) {
        
        TextView title = ViewHolder.get(view, R.id.title);
        
        if (item.fromCity != null && item.toCity != null){
            title.setText(" from " + item.fromCity + " to " + item.toCity);
            
        }
        
        TextView subtitle = ViewHolder.get(view, R.id.subtitle);
        
        if (item.scheduledDelivery != null && item.status != null){
            subtitle.setText("Deliver on " + DateFormat.getMediumDateFormat(getActivity()).format(item.scheduledDelivery) + " [" + item.status + "]");
            
        }
    }


    @Override
    public void showDetail(ShipmentsDSItem item, int position) {
        Bundle args = new Bundle();
        args.putInt(Constants.ITEMPOS, position);
        args.putParcelable(Constants.CONTENT, item);
        Intent intent = new Intent(getActivity(), AvailabilityMenuItem1DetailActivity.class);
        intent.putExtras(args);

        if (!getResources().getBoolean(R.bool.tabletLayout)) {
            startActivityForResult(intent, Constants.DETAIL);
        } else {
            startActivity(intent);
        }
    }

}

