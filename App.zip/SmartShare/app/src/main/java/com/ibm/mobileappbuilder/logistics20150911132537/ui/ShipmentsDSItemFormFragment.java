
package com.ibm.mobileappbuilder.logistics20150911132537.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.ShipmentsDSItem;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.ShipmentsDSService;
import com.ibm.mobileappbuilder.logistics20150911132537.presenters.AvailabilityMenuItem1DetailFormPresenter;
import com.ibm.mobileappbuilder.logistics20150911132537.R;
import ibmmobileappbuilder.ui.FormFragment;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.views.DatePicker;
import ibmmobileappbuilder.views.TextWatcherAdapter;
import java.util.Date;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.ShipmentsDSItem;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.ShipmentsDS;

public class ShipmentsDSItemFormFragment extends FormFragment<ShipmentsDSItem> {

    private CrudDatasource<ShipmentsDSItem> datasource;

    public static ShipmentsDSItemFormFragment newInstance(Bundle args){
        ShipmentsDSItemFormFragment fr = new ShipmentsDSItemFormFragment();
        fr.setArguments(args);

        return fr;
    }

    public ShipmentsDSItemFormFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        // the presenter for this view
        setPresenter(new AvailabilityMenuItem1DetailFormPresenter(
                (CrudDatasource) getDatasource(),
                this));

            }

    @Override
    protected ShipmentsDSItem newItem() {
        return new ShipmentsDSItem();
    }

    private ShipmentsDSService getRestService(){
        return ShipmentsDSService.getInstance();
    }

    @Override
    protected int getLayout() {
        return R.layout.availabilitymenuitem1detail_form;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final ShipmentsDSItem item, View view) {
        
        bindLong(R.id.shipmentsds_vechicleid, item.vechicleId, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.vechicleId = StringUtils.parseLong(s.toString());
            }
        });
        
        
        bindDatePicker(R.id.shipmentsds_pickup, item.pickup, new DatePicker.DateSelectedListener() {
            @Override
            public void onSelected(Date selected) {
                item.pickup = selected;
            }
        });
        
        
        bindDatePicker(R.id.shipmentsds_scheduleddelivery, item.scheduledDelivery, new DatePicker.DateSelectedListener() {
            @Override
            public void onSelected(Date selected) {
                item.scheduledDelivery = selected;
            }
        });
        
        
        bindString(R.id.shipmentsds_fromaddress, item.fromAddress, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.fromAddress = s.toString();
            }
        });
        
        
        bindString(R.id.shipmentsds_fromcity, item.fromCity, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.fromCity = s.toString();
            }
        });
        
        
        bindLong(R.id.shipmentsds_fromzip, item.fromZIP, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.fromZIP = StringUtils.parseLong(s.toString());
            }
        });
        
        
        bindString(R.id.shipmentsds_fromcountry, item.fromCountry, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.fromCountry = s.toString();
            }
        });
        
        
        bindString(R.id.shipmentsds_toaddress, item.toAddress, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.toAddress = s.toString();
            }
        });
        
        
        bindString(R.id.shipmentsds_tocity, item.toCity, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.toCity = s.toString();
            }
        });
        
        
        bindLong(R.id.shipmentsds_tozip, item.toZIP, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.toZIP = StringUtils.parseLong(s.toString());
            }
        });
        
        
        bindString(R.id.shipmentsds_tocountry, item.toCountry, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.toCountry = s.toString();
            }
        });
        
        
        bindString(R.id.shipmentsds_status, item.status, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.status = s.toString();
            }
        });
        
    }

    @Override
    public Datasource<ShipmentsDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = ShipmentsDS.getInstance(new SearchOptions());
        return datasource;
    }
}

