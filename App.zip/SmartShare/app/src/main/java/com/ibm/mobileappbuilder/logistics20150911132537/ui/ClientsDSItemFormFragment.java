
package com.ibm.mobileappbuilder.logistics20150911132537.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.ClientsDSItem;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.ClientsDSService;
import com.ibm.mobileappbuilder.logistics20150911132537.presenters.SpotsFormPresenter;
import com.ibm.mobileappbuilder.logistics20150911132537.R;
import ibmmobileappbuilder.ui.FormFragment;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.views.TextWatcherAdapter;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.ClientsDSItem;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.ClientsDS;

public class ClientsDSItemFormFragment extends FormFragment<ClientsDSItem> {

    private CrudDatasource<ClientsDSItem> datasource;

    public static ClientsDSItemFormFragment newInstance(Bundle args){
        ClientsDSItemFormFragment fr = new ClientsDSItemFormFragment();
        fr.setArguments(args);

        return fr;
    }

    public ClientsDSItemFormFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        // the presenter for this view
        setPresenter(new SpotsFormPresenter(
                (CrudDatasource) getDatasource(),
                this));

            }

    @Override
    protected ClientsDSItem newItem() {
        return new ClientsDSItem();
    }

    private ClientsDSService getRestService(){
        return ClientsDSService.getInstance();
    }

    @Override
    protected int getLayout() {
        return R.layout.spots_form;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final ClientsDSItem item, View view) {
        
        bindLong(R.id.clientsds_spotid, item.spotID, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.spotID = StringUtils.parseLong(s.toString());
            }
        });
        
        
        bindString(R.id.clientsds_name, item.name, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.name = s.toString();
            }
        });
        
        
        bindString(R.id.clientsds_phone, item.phone, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.phone = s.toString();
            }
        });
        
        
        bindString(R.id.clientsds_email, item.email, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.email = s.toString();
            }
        });
        
        
        bindString(R.id.clientsds_address, item.address, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.address = s.toString();
            }
        });
        
        
        bindLong(R.id.clientsds_zipcode, item.zIPCode, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.zIPCode = StringUtils.parseLong(s.toString());
            }
        });
        
        
        bindString(R.id.clientsds_city, item.city, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.city = s.toString();
            }
        });
        
        
        bindString(R.id.clientsds_country, item.country, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.country = s.toString();
            }
        });
        
    }

    @Override
    public Datasource<ClientsDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = ClientsDS.getInstance(new SearchOptions());
        return datasource;
    }
}

