
package com.ibm.mobileappbuilder.logistics20150911132537.ds;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class VehiclesDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("serial") public Long serial;
    @SerializedName("make") public String make;
    @SerializedName("model") public String model;
    @SerializedName("engine") public String engine;
    @SerializedName("miles") public Long miles;
    @SerializedName("status") public String status;
    @SerializedName("id") public String id;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(serial);
        dest.writeString(make);
        dest.writeString(model);
        dest.writeString(engine);
        dest.writeValue(miles);
        dest.writeString(status);
        dest.writeString(id);
    }

    public static final Creator<VehiclesDSItem> CREATOR = new Creator<VehiclesDSItem>() {
        @Override
        public VehiclesDSItem createFromParcel(Parcel in) {
            VehiclesDSItem item = new VehiclesDSItem();

            item.serial = (Long) in.readValue(null);
            item.make = in.readString();
            item.model = in.readString();
            item.engine = in.readString();
            item.miles = (Long) in.readValue(null);
            item.status = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public VehiclesDSItem[] newArray(int size) {
            return new VehiclesDSItem[size];
        }
    };

}


