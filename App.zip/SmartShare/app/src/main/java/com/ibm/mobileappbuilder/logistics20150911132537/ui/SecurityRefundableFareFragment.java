package com.ibm.mobileappbuilder.logistics20150911132537.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import com.ibm.mobileappbuilder.logistics20150911132537.R;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ui.ListGridFragment;
import ibmmobileappbuilder.util.ViewHolder;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.SecurityDSItem;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.SecurityDS;
import android.content.Intent;
import ibmmobileappbuilder.util.Constants;

import static ibmmobileappbuilder.util.NavigationUtils.generateIntentToAddOrUpdateItem;

/**
 * "SecurityRefundableFareFragment" listing
 */
public class SecurityRefundableFareFragment extends ListGridFragment<SecurityDSItem>  {

    private Datasource<SecurityDSItem> datasource;


    public static SecurityRefundableFareFragment newInstance(Bundle args) {
        SecurityRefundableFareFragment fr = new SecurityRefundableFareFragment();

        fr.setArguments(args);
        return fr;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    protected SearchOptions getSearchOptions() {
      SearchOptions.Builder searchOptionsBuilder = SearchOptions.Builder.searchOptions();
      return searchOptionsBuilder.build();
    }


    /**
    * Layout for the list itselft
    */
    @Override
    protected int getLayout() {
        return R.layout.fragment_list;
    }

    /**
    * Layout for each element in the list
    */
    @Override
    protected int getItemLayout() {
        return R.layout.securityrefundablefare_item;
    }

    @Override
    protected Datasource<SecurityDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
      datasource = SecurityDS.getInstance(getSearchOptions());
      return datasource;
    }

    @Override
    protected void bindView(SecurityDSItem item, View view, int position) {
        
        TextView title = ViewHolder.get(view, R.id.title);
        
        if (item.distance != null){
            title.setText(item.distance.toString());
            
        }
        
        TextView subtitle = ViewHolder.get(view, R.id.subtitle);
        
        if (item.distance != null){
            subtitle.setText(item.distance.toString());
            
        }
    }


    @Override
    public void showDetail(SecurityDSItem item, int position) {
        Bundle args = new Bundle();
        args.putInt(Constants.ITEMPOS, position);
        args.putParcelable(Constants.CONTENT, item);
        Intent intent = new Intent(getActivity(), SecurityRefundableFareDetailActivity.class);
        intent.putExtras(args);

        if (!getResources().getBoolean(R.bool.tabletLayout)) {
            startActivityForResult(intent, Constants.DETAIL);
        } else {
            startActivity(intent);
        }
    }

}

