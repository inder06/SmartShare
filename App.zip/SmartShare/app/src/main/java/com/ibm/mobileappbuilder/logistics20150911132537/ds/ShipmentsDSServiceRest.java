
package com.ibm.mobileappbuilder.logistics20150911132537.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;

public interface ShipmentsDSServiceRest{

	@GET("/app/57ef4eee57acb00300064c3f/r/shipmentsDS")
	void queryShipmentsDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<ShipmentsDSItem>> cb);

	@GET("/app/57ef4eee57acb00300064c3f/r/shipmentsDS/{id}")
	void getShipmentsDSItemById(@Path("id") String id, Callback<ShipmentsDSItem> cb);

	@DELETE("/app/57ef4eee57acb00300064c3f/r/shipmentsDS/{id}")
  void deleteShipmentsDSItemById(@Path("id") String id, Callback<ShipmentsDSItem> cb);

  @POST("/app/57ef4eee57acb00300064c3f/r/shipmentsDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<ShipmentsDSItem>> cb);

  @POST("/app/57ef4eee57acb00300064c3f/r/shipmentsDS")
  void createShipmentsDSItem(@Body ShipmentsDSItem item, Callback<ShipmentsDSItem> cb);

  @PUT("/app/57ef4eee57acb00300064c3f/r/shipmentsDS/{id}")
  void updateShipmentsDSItem(@Path("id") String id, @Body ShipmentsDSItem item, Callback<ShipmentsDSItem> cb);

  @GET("/app/57ef4eee57acb00300064c3f/r/shipmentsDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
}

