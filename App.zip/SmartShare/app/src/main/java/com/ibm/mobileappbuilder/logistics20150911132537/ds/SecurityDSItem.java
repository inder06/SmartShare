
package com.ibm.mobileappbuilder.logistics20150911132537.ds;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class SecurityDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("distance") public Long distance;
    @SerializedName("amount") public Long amount;
    @SerializedName("id") public String id;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(distance);
        dest.writeValue(amount);
        dest.writeString(id);
    }

    public static final Creator<SecurityDSItem> CREATOR = new Creator<SecurityDSItem>() {
        @Override
        public SecurityDSItem createFromParcel(Parcel in) {
            SecurityDSItem item = new SecurityDSItem();

            item.distance = (Long) in.readValue(null);
            item.amount = (Long) in.readValue(null);
            item.id = in.readString();
            return item;
        }

        @Override
        public SecurityDSItem[] newArray(int size) {
            return new SecurityDSItem[size];
        }
    };

}


