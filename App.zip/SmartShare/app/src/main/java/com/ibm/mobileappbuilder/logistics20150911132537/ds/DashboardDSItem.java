
package com.ibm.mobileappbuilder.logistics20150911132537.ds;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class DashboardDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("status") public String status;
    @SerializedName("shipments") public Long shipments;
    @SerializedName("id") public String id;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(status);
        dest.writeValue(shipments);
        dest.writeString(id);
    }

    public static final Creator<DashboardDSItem> CREATOR = new Creator<DashboardDSItem>() {
        @Override
        public DashboardDSItem createFromParcel(Parcel in) {
            DashboardDSItem item = new DashboardDSItem();

            item.status = in.readString();
            item.shipments = (Long) in.readValue(null);
            item.id = in.readString();
            return item;
        }

        @Override
        public DashboardDSItem[] newArray(int size) {
            return new DashboardDSItem[size];
        }
    };

}


