
package com.ibm.mobileappbuilder.logistics20150911132537.ui;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.ShipmentsDSService;
import com.ibm.mobileappbuilder.logistics20150911132537.presenters.AvailabilityMenuItem1DetailPresenter;
import com.ibm.mobileappbuilder.logistics20150911132537.R;
import ibmmobileappbuilder.actions.ActivityIntentLauncher;
import ibmmobileappbuilder.actions.MapsAction;
import ibmmobileappbuilder.behaviors.FabBehaviour;
import ibmmobileappbuilder.mvp.presenter.DetailCrudPresenter;
import ibmmobileappbuilder.util.ColorUtils;
import ibmmobileappbuilder.util.Constants;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.ShipmentsDSItem;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.ShipmentsDS;

public class AvailabilityMenuItem1DetailFragment extends ibmmobileappbuilder.ui.DetailFragment<ShipmentsDSItem>  {

    private CrudDatasource<ShipmentsDSItem> datasource;
    public static AvailabilityMenuItem1DetailFragment newInstance(Bundle args){
        AvailabilityMenuItem1DetailFragment fr = new AvailabilityMenuItem1DetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public AvailabilityMenuItem1DetailFragment(){
        super();
    }

    @Override
    public Datasource<ShipmentsDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = ShipmentsDS.getInstance(new SearchOptions());
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        // the presenter for this view
        setPresenter(new AvailabilityMenuItem1DetailPresenter(
                (CrudDatasource) getDatasource(),
                this));
        // Edit button
        addBehavior(new FabBehaviour(this, R.drawable.ic_edit_white, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((DetailCrudPresenter<ShipmentsDSItem>) getPresenter()).editForm(getItem());
            }
        }));

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.availabilitymenuitem1detail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final ShipmentsDSItem item, View view) {
        if (item.status != null){
            
            TextView view0 = (TextView) view.findViewById(R.id.view0);
            view0.setText(item.status);
            
        }
        if (item.fromCity != null && item.fromZIP != null){
            
            TextView view1 = (TextView) view.findViewById(R.id.view1);
            view1.setText(", " + item.fromCity + ", " + item.fromZIP.toString());
            bindAction(view1, new MapsAction(
            new ActivityIntentLauncher()
            , "http://maps.google.com/maps?q=" + item.fromAddress + ", " + item.fromCity + ", " + item.fromZIP.toString()));
        }
        if (item.scheduledDelivery != null){
            
            TextView view2 = (TextView) view.findViewById(R.id.view2);
            view2.setText(DateFormat.getMediumDateFormat(getActivity()).format(item.scheduledDelivery));
            
        }
    }

    @Override
    protected void onShow(ShipmentsDSItem item) {
        // set the title for this fragment
        getActivity().setTitle("Order #" + item.vechicleId.toString());
    }

    @Override
    public void navigateToEditForm() {
        Bundle args = new Bundle();

        args.putInt(Constants.ITEMPOS, 0);
        args.putParcelable(Constants.CONTENT, getItem());
        args.putInt(Constants.MODE, Constants.MODE_EDIT);

        Intent intent = new Intent(getActivity(), ShipmentsDSItemFormActivity.class);
        intent.putExtras(args);
        startActivityForResult(intent, Constants.MODE_EDIT);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.delete_menu, menu);

        MenuItem item = menu.findItem(R.id.action_delete);
        ColorUtils.tintIcon(item, R.color.textBarColor, getActivity());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.action_delete){
            ((DetailCrudPresenter<ShipmentsDSItem>) getPresenter()).deleteItem(getItem());
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}

