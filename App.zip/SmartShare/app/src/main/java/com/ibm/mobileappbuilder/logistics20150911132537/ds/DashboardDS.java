

package com.ibm.mobileappbuilder.logistics20150911132537.ds;

import android.content.Context;

import java.net.URL;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.ds.restds.TypedByteArrayUtils;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * "DashboardDS" data source. (e37eb8dc-6eb2-4635-8592-5eb9696050e3)
 */
public class DashboardDS extends AppNowDatasource<DashboardDSItem>{

    // default page size
    private static final int PAGE_SIZE = 20;

    private DashboardDSService service;

    public static DashboardDS getInstance(SearchOptions searchOptions){
        return new DashboardDS(searchOptions);
    }

    private DashboardDS(SearchOptions searchOptions) {
        super(searchOptions);
        this.service = DashboardDSService.getInstance();
    }

    @Override
    public void getItem(String id, final Listener<DashboardDSItem> listener) {
        if ("0".equals(id)) {
                        getItems(new Listener<List<DashboardDSItem>>() {
                @Override
                public void onSuccess(List<DashboardDSItem> items) {
                    if(items != null && items.size() > 0) {
                        listener.onSuccess(items.get(0));
                    } else {
                        listener.onSuccess(new DashboardDSItem());
                    }
                }

                @Override
                public void onFailure(Exception e) {
                    listener.onFailure(e);
                }
            });
        } else {
                      service.getServiceProxy().getDashboardDSItemById(id, new Callback<DashboardDSItem>() {
                @Override
                public void success(DashboardDSItem result, Response response) {
                                        listener.onSuccess(result);
                }

                @Override
                public void failure(RetrofitError error) {
                                        listener.onFailure(error);
                }
            });
        }
    }

    @Override
    public void getItems(final Listener<List<DashboardDSItem>> listener) {
        getItems(0, listener);
    }

    @Override
    public void getItems(int pagenum, final Listener<List<DashboardDSItem>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
        int skipNum = pagenum * PAGE_SIZE;
        String skip = skipNum == 0 ? null : String.valueOf(skipNum);
        String limit = PAGE_SIZE == 0 ? null: String.valueOf(PAGE_SIZE);
        String sort = getSort(searchOptions);
                service.getServiceProxy().queryDashboardDSItem(
                skip,
                limit,
                conditions,
                sort,
                null,
                null,
                new Callback<List<DashboardDSItem>>() {
            @Override
            public void success(List<DashboardDSItem> result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    private String[] getSearchableFields() {
        return new String[]{"status"};
    }

    // Pagination

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getUniqueValuesFor(String searchStr, final Listener<List<String>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
                service.getServiceProxy().distinct(searchStr, conditions, new Callback<List<String>>() {
             @Override
             public void success(List<String> result, Response response) {
                                  result.removeAll(Collections.<String>singleton(null));
                 listener.onSuccess(result);
             }

             @Override
             public void failure(RetrofitError error) {
                                  listener.onFailure(error);
             }
        });
    }

    @Override
    public URL getImageUrl(String path) {
        return service.getImageUrl(path);
    }

    @Override
    public void create(DashboardDSItem item, Listener<DashboardDSItem> listener) {
                          service.getServiceProxy().createDashboardDSItem(item, callbackFor(listener));
          }

    private Callback<DashboardDSItem> callbackFor(final Listener<DashboardDSItem> listener) {
      return new Callback<DashboardDSItem>() {
          @Override
          public void success(DashboardDSItem item, Response response) {
                            listener.onSuccess(item);
          }

          @Override
          public void failure(RetrofitError error) {
                            listener.onFailure(error);
          }
      };
    }

    @Override
    public void updateItem(DashboardDSItem item, Listener<DashboardDSItem> listener) {
                          service.getServiceProxy().updateDashboardDSItem(item.getIdentifiableId(), item, callbackFor(listener));
          }

    @Override
    public void deleteItem(DashboardDSItem item, final Listener<DashboardDSItem> listener) {
                service.getServiceProxy().deleteDashboardDSItemById(item.getIdentifiableId(), new Callback<DashboardDSItem>() {
            @Override
            public void success(DashboardDSItem result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    @Override
    public void deleteItems(List<DashboardDSItem> items, final Listener<DashboardDSItem> listener) {
                service.getServiceProxy().deleteByIds(collectIds(items), new Callback<List<DashboardDSItem>>() {
            @Override
            public void success(List<DashboardDSItem> item, Response response) {
                                listener.onSuccess(null);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    protected List<String> collectIds(List<DashboardDSItem> items){
        List<String> ids = new ArrayList<>();
        for(DashboardDSItem item: items){
            ids.add(item.getIdentifiableId());
        }
        return ids;
    }

}

