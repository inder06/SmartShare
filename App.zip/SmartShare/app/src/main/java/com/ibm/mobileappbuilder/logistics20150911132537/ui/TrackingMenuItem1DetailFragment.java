
package com.ibm.mobileappbuilder.logistics20150911132537.ui;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.VehiclesDSService;
import com.ibm.mobileappbuilder.logistics20150911132537.presenters.TrackingMenuItem1DetailPresenter;
import com.ibm.mobileappbuilder.logistics20150911132537.R;
import ibmmobileappbuilder.behaviors.FabBehaviour;
import ibmmobileappbuilder.behaviors.ShareBehavior;
import ibmmobileappbuilder.mvp.presenter.DetailCrudPresenter;
import ibmmobileappbuilder.util.ColorUtils;
import ibmmobileappbuilder.util.Constants;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.VehiclesDSItem;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.VehiclesDS;

public class TrackingMenuItem1DetailFragment extends ibmmobileappbuilder.ui.DetailFragment<VehiclesDSItem> implements ShareBehavior.ShareListener  {

    private CrudDatasource<VehiclesDSItem> datasource;
    public static TrackingMenuItem1DetailFragment newInstance(Bundle args){
        TrackingMenuItem1DetailFragment fr = new TrackingMenuItem1DetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public TrackingMenuItem1DetailFragment(){
        super();
    }

    @Override
    public Datasource<VehiclesDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = VehiclesDS.getInstance(new SearchOptions());
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        // the presenter for this view
        setPresenter(new TrackingMenuItem1DetailPresenter(
                (CrudDatasource) getDatasource(),
                this));
        // Edit button
        addBehavior(new FabBehaviour(this, R.drawable.ic_edit_white, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((DetailCrudPresenter<VehiclesDSItem>) getPresenter()).editForm(getItem());
            }
        }));
        addBehavior(new ShareBehavior(getActivity(), this));

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.trackingmenuitem1detail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final VehiclesDSItem item, View view) {
        if (item.serial != null){
            
            TextView view0 = (TextView) view.findViewById(R.id.view0);
            view0.setText(item.serial.toString());
            
        }
        if (item.status != null){
            
            TextView view1 = (TextView) view.findViewById(R.id.view1);
            view1.setText(item.status);
            
        }
        if (item.miles != null){
            
            TextView view2 = (TextView) view.findViewById(R.id.view2);
            view2.setText(item.miles.toString());
            
        }
    }

    @Override
    protected void onShow(VehiclesDSItem item) {
        // set the title for this fragment
        getActivity().setTitle("VecNo");
    }

    @Override
    public void navigateToEditForm() {
        Bundle args = new Bundle();

        args.putInt(Constants.ITEMPOS, 0);
        args.putParcelable(Constants.CONTENT, getItem());
        args.putInt(Constants.MODE, Constants.MODE_EDIT);

        Intent intent = new Intent(getActivity(), VehiclesDSItemFormActivity.class);
        intent.putExtras(args);
        startActivityForResult(intent, Constants.MODE_EDIT);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.delete_menu, menu);

        MenuItem item = menu.findItem(R.id.action_delete);
        ColorUtils.tintIcon(item, R.color.textBarColor, getActivity());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.action_delete){
            ((DetailCrudPresenter<VehiclesDSItem>) getPresenter()).deleteItem(getItem());
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onShare() {
        VehiclesDSItem item = getItem();

        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");

        intent.putExtra(Intent.EXTRA_TEXT, (item.serial != null ? item.serial.toString() : "" ) + "\n" +
                    (item.status != null ? item.status : "" ) + "\n" +
                    (item.miles != null ? item.miles.toString() : "" ));
        intent.putExtra(Intent.EXTRA_SUBJECT, "VecNo");
        startActivityForResult(Intent.createChooser(intent, getString(R.string.share)), 1);
    }
}

