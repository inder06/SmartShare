
package com.ibm.mobileappbuilder.logistics20150911132537.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;

public interface SecurityDSServiceRest{

	@GET("/app/57ef4eee57acb00300064c3f/r/securityDS")
	void querySecurityDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<SecurityDSItem>> cb);

	@GET("/app/57ef4eee57acb00300064c3f/r/securityDS/{id}")
	void getSecurityDSItemById(@Path("id") String id, Callback<SecurityDSItem> cb);

	@DELETE("/app/57ef4eee57acb00300064c3f/r/securityDS/{id}")
  void deleteSecurityDSItemById(@Path("id") String id, Callback<SecurityDSItem> cb);

  @POST("/app/57ef4eee57acb00300064c3f/r/securityDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<SecurityDSItem>> cb);

  @POST("/app/57ef4eee57acb00300064c3f/r/securityDS")
  void createSecurityDSItem(@Body SecurityDSItem item, Callback<SecurityDSItem> cb);

  @PUT("/app/57ef4eee57acb00300064c3f/r/securityDS/{id}")
  void updateSecurityDSItem(@Path("id") String id, @Body SecurityDSItem item, Callback<SecurityDSItem> cb);

  @GET("/app/57ef4eee57acb00300064c3f/r/securityDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
}

