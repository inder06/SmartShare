
package com.ibm.mobileappbuilder.logistics20150911132537.presenters;

import com.ibm.mobileappbuilder.logistics20150911132537.R;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.ShipmentsDSItem;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.DetailCrudPresenter;
import ibmmobileappbuilder.mvp.view.DetailView;

public class AvailabilityMenuItem1DetailPresenter extends BasePresenter implements DetailCrudPresenter<ShipmentsDSItem>,
      Datasource.Listener<ShipmentsDSItem> {

    private final CrudDatasource<ShipmentsDSItem> datasource;
    private final DetailView view;

    public AvailabilityMenuItem1DetailPresenter(CrudDatasource<ShipmentsDSItem> datasource, DetailView view){
        this.datasource = datasource;
        this.view = view;
    }

    @Override
    public void deleteItem(ShipmentsDSItem item) {
        datasource.deleteItem(item, this);
    }

    @Override
    public void editForm(ShipmentsDSItem item) {
        view.navigateToEditForm();
    }

    @Override
    public void onSuccess(ShipmentsDSItem item) {
                view.showMessage(R.string.item_deleted, true);
        view.close(true);
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic, true);
    }
}

