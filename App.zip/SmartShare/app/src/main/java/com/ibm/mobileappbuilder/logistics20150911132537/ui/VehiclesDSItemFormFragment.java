
package com.ibm.mobileappbuilder.logistics20150911132537.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.VehiclesDSItem;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.VehiclesDSService;
import com.ibm.mobileappbuilder.logistics20150911132537.presenters.TrackingMenuItem1FormPresenter;
import com.ibm.mobileappbuilder.logistics20150911132537.R;
import ibmmobileappbuilder.ui.FormFragment;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.views.TextWatcherAdapter;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.VehiclesDSItem;
import com.ibm.mobileappbuilder.logistics20150911132537.ds.VehiclesDS;

public class VehiclesDSItemFormFragment extends FormFragment<VehiclesDSItem> {

    private CrudDatasource<VehiclesDSItem> datasource;

    public static VehiclesDSItemFormFragment newInstance(Bundle args){
        VehiclesDSItemFormFragment fr = new VehiclesDSItemFormFragment();
        fr.setArguments(args);

        return fr;
    }

    public VehiclesDSItemFormFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        // the presenter for this view
        setPresenter(new TrackingMenuItem1FormPresenter(
                (CrudDatasource) getDatasource(),
                this));

            }

    @Override
    protected VehiclesDSItem newItem() {
        return new VehiclesDSItem();
    }

    private VehiclesDSService getRestService(){
        return VehiclesDSService.getInstance();
    }

    @Override
    protected int getLayout() {
        return R.layout.trackingmenuitem1_form;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final VehiclesDSItem item, View view) {
        
        bindLong(R.id.vehiclesds_serial, item.serial, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.serial = StringUtils.parseLong(s.toString());
            }
        });
        
        
        bindString(R.id.vehiclesds_make, item.make, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.make = s.toString();
            }
        });
        
        
        bindString(R.id.vehiclesds_model, item.model, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.model = s.toString();
            }
        });
        
        
        bindString(R.id.vehiclesds_engine, item.engine, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.engine = s.toString();
            }
        });
        
        
        bindLong(R.id.vehiclesds_miles, item.miles, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.miles = StringUtils.parseLong(s.toString());
            }
        });
        
        
        bindString(R.id.vehiclesds_status, item.status, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.status = s.toString();
            }
        });
        
    }

    @Override
    public Datasource<VehiclesDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = VehiclesDS.getInstance(new SearchOptions());
        return datasource;
    }
}

